# -*- coding: utf-8 -*-
{
    'name': "Taller mod",

    'summary': """
        Modificaciones para el modulo de taller""",

    'description': """
        Se modificaran un parte de modulo de Taller asi como agregar una parte nueva
    """,

    'author': "ogum",
    'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/12.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','car_repair_maintenance_service'],

    # always loaded
    'data': [
         'security/ir.model.access.csv',
          'views/Taller_modifica.xml',

    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}

#-*- coding: utf-8 -*-

from odoo import models, fields, api,_
from odoo.exceptions import UserError

class Taller_Car_nombre_exterior(models.Model):

    _name="name.car.nombre_exterior"

    _rec_name="nombre_ext"

    nombre_ext = fields.Char(string="Nombre")

#-*- coding: utf-8 -*-

from odoo import models, fields, api,_
from odoo.exceptions import UserError

class Taller_Car_nombre_interior(models.Model):

    _name="name.car.nombre_interior"

    _rec_name="nombre_int"

    nombre_int = fields.Char(string="Nombre")

#-*- coding: utf-8 -*-

from odoo import models, fields, api,_
from odoo.exceptions import UserError

class Taller_Car_interior(models.Model):

    _name="car_piezas.interiores"

    _description="Nombre de piezas interiores"    

    nombre = fields.Many2one('name.car.nombre_interior',string="Nombre")

    si = fields.Boolean(string="SI")

    No = fields.Boolean(string="No")

    imagen = fields.Binary(string="Imagen")

    interiores_id=fields.Many2one('car.repair.support',string="interiores")

#-*- coding: utf-8 -*-

from odoo import models, fields, api,_
from odoo.exceptions import UserError

class Taller_Car_nombre_accesorio(models.Model):

    _name="name.car.nombre_accesorio"

    _rec_name="nombre_acces"

    nombre_acces = fields.Char(string="Nombre")

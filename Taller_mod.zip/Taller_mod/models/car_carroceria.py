#-*- coding: utf-8 -*-

from odoo import models, fields, api,_
from odoo.exceptions import UserError

class Taller_corroceria(models.Model):

    _name="car_piezas.carroceria"

    _description="Nombre de piezas carroceria"

    nombre = fields.Many2one('name.car.nombre_caroseria',string="Nombre")

    si = fields.Boolean(string="SI")

    No = fields.Boolean(string="No")

    imagen = fields.Binary(string="Imagen")

    carroceria_id=fields.Many2one('car.repair.support',string="carroceria")

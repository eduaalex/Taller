#-*- coding: utf-8 -*-

from odoo import models, fields, api,_
from odoo.exceptions import UserError

class Taller_mecanico(models.Model):

    _name="car_piezas.mecanico"

    _description="Nombre de piezas mecanico"

    nombre = fields.Many2one('name.car.nombre_mecanico',string="Nombre")

    si = fields.Boolean(string="SI")

    No = fields.Boolean(string="No")

    imagen = fields.Binary(string="Imagen")

    mecanico_id=fields.Many2one('car.repair.support',string="mecanico")

#-*- coding: utf-8 -*-

from odoo import models, fields, api,_
from odoo.exceptions import UserError

class Taller_Car_nombre_correseria(models.Model):

    _name="name.car.nombre_caroseria"

    _rec_name="nombre_carro"

    nombre_carro = fields.Char(string="Nombre")

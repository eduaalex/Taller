#-*- coding: utf-8 -*-

from odoo import models, fields, api,_
from odoo.exceptions import UserError

class Taller_Car_nombre_mecanico(models.Model):

    _name="name.car.nombre_mecanico"

    _rec_name="nombre_mecanico"

    nombre_mecanico = fields.Char(string="Nombre")

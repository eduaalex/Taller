#-*- coding: utf-8 -*-

from odoo import models, fields, api,_
from odoo.exceptions import UserError

class Taller_exterior(models.Model):

    _name="car_piezas.exteriores"

    _description="Nombre de piezas exteriores"

    nombre = fields.Many2one('name.car.nombre_exterior',string="Nombre")

    si = fields.Boolean(string="SI")

    No = fields.Boolean(string="No")

    imagen = fields.Binary(string="Imagen")

    exteriores_id=fields.Many2one('car.repair.support',string="exteriores")

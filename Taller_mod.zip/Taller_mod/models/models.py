#-*- coding: utf-8 -*-

from odoo import models, fields, api,_
from odoo.exceptions import UserError

class Taller_modificar(models.Model):

    _inherit = 'car.repair.support'

    _description='Inventario y estado de vehiculo'

    combustible = fields.Selection(
        string="Combustible",
        selection=[
                ('1', '1/1'),
                ('2', '3/4'),
                ('3', '1/2'),
                ('4', '0/1'),
        ],
    )

    suministrorefa_asny = fields.Boolean(string="NCS")
    suministrorefa_cliente=fields.Boolean(string="Cliente")
    #componente mecanico
    bateria = fields.Text(string="Bateria")

    dano_interiores = fields.Boolean(string="Daños Interiores")
    dano_exterior = fields.Boolean(string="Daños Exterior")
    dano_mecanico = fields.Boolean(string="Daños Mecanicos")
    dano_carroceria = fields.Boolean(string="Daños Carrocería")
    dano_accesorios = fields.Boolean(string="Daños Accesorios")


    lines_accesorios = fields.One2many('car_piezas.accesorios','accesorios_id',
        string="Accesorios")
    lines_carroceria = fields.One2many('car_piezas.carroceria','carroceria_id',
        string="Carroceria")
    lines_mecanico = fields.One2many('car_piezas.mecanico','mecanico_id',
        string="Mecanico")
    lines_exterior = fields.One2many('car_piezas.exteriores','exteriores_id',
        string="Exterior")
    lines_interiores = fields.One2many('car_piezas.interiores','interiores_id',
        string="interiores")

    comentario = fields.Text(string="Comentario")

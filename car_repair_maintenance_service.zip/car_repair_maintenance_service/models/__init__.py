# -*- coding: utf-8 -*-

from . import analytic_account_line

from . import car_repair_support
from . import support_team
#from . import support_invoice odoo13 not used
from . import ticket_task

from . import product
from . import repair_types
from . import product_consume_part
from . import nature_of_service
from . import repair_estimation_lines
from . import sale
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
